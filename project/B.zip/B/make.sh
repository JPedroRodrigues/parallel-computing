gcc solution.c -o solution.out -O3 -Wall

time -p ./solution.out

rm -if *.out