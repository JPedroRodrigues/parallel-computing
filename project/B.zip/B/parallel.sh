gcc parallelSolution.c -o parallelSolution.out -O3 -Wall -fopenmp

time -p OMP_NUM_THREADS=160 ./parallelSolution.out

rm -if .out